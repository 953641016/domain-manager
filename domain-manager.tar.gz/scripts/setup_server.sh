#!/bin/bash
set -e

echo "=== 1. 创建项目目录 ==="
mkdir -p /opt/domain-manager
cd /opt/domain-manager

echo "=== 2. 克隆项目 ==="
if [ -d ".git" ]; then
    git pull origin main
else
    git clone https://github.com/953641016/domain-manager.git .
fi

echo "=== 3. 配置后端环境变量 ==="
if [ ! -f "backend/.env" ]; then
    cat > backend/.env << 'ENVEOF'
# 飞书应用配置
FEISHU_APP_ID=cli_aa90bce2dd78dbdf
FEISHU_APP_SECRET=zDodBxkkPRlSSpt2ejLjRhxJXNYpN5gk

# JWT配置
JWT_SECRET_KEY=domain-manager-secret-key-2024
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=1440

# 超级管理员飞书用户ID（部署后获取）
SUPER_ADMIN_FEISHU_USER_ID=

# 数据库配置
DATABASE_URL=sqlite:///./data/domainmgr.db

# 回调地址
FEISHU_REDIRECT_URI=https://d.fwxg.com/dm/api/v1/auth/feishu/callback

# 服务器配置
SERVER_HOST=0.0.0.0
SERVER_PORT=8000
DEBUG=false
ENVEOF
    echo "后端环境变量已创建"
else
    echo "后端环境变量已存在"
fi

echo "=== 4. 创建必要目录 ==="
mkdir -p backend/data
mkdir -p backend/logs

echo "=== 5. 设置权限 ==="
chmod 600 backend/.env

echo "=== 项目准备完成 ==="
ls -la
