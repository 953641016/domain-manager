import hashlib
import hmac
import json
import sys
import time
import urllib.request
from datetime import datetime, timezone

SECRET_ID = "AKIDT8vHlEjUegDQt7nLZLdrTV3svry2C8fU"
SECRET_KEY = sys.argv[1] if len(sys.argv) > 1 else input("请输入你的 SecretKey: ").strip()

SERVICE = "dnspod"
HOST = "dnspod.tencentcloudapi.com"
ENDPOINT = f"https://{HOST}"
ACTION = "DescribeDomainList"
VERSION = "2021-03-23"
ALGORITHM = "TC3-HMAC-SHA256"


def sign(key: bytes, msg: str) -> bytes:
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()


def main():
    timestamp = int(time.time())
    payload = json.dumps({"Type": 1})
    date = datetime.fromtimestamp(timestamp, tz=timezone.utc).strftime("%Y-%m-%d")

    canonical_request = (
        "POST\n/\n\n"
        "content-type:application/json\n"
        f"host:{HOST}\n"
        f"x-tc-action:{ACTION.lower()}\n\n"
        "content-type;host;x-tc-action\n"
        f"{hashlib.sha256(payload.encode('utf-8')).hexdigest()}"
    )
    credential_scope = f"{date}/{SERVICE}/tc3_request"
    string_to_sign = (
        f"{ALGORITHM}\n"
        f"{timestamp}\n"
        f"{credential_scope}\n"
        f"{hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()}"
    )

    secret_date = sign(("TC3" + SECRET_KEY).encode("utf-8"), date)
    secret_service = sign(secret_date, SERVICE)
    secret_signing = sign(secret_service, "tc3_request")
    signature = hmac.new(secret_signing, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()

    authorization = (
        f"{ALGORITHM} "
        f"Credential={SECRET_ID}/{date}/{SERVICE}/tc3_request, "
        f"SignedHeaders=content-type;host;x-tc-action, "
        f"Signature={signature}"
    )

    headers = {
        "Authorization": authorization,
        "Content-Type": "application/json",
        "Host": HOST,
        "X-TC-Action": ACTION,
        "X-TC-Version": VERSION,
        "X-TC-Timestamp": str(timestamp),
    }

    req = urllib.request.Request(ENDPOINT, data=payload.encode("utf-8"), headers=headers, method="POST")
    with urllib.request.urlopen(req) as resp:
        result = json.loads(resp.read().decode("utf-8"))

    if "Response" in result and "DomainList" in result["Response"]:
        domains = result["Response"]["DomainList"]
        print(f"\n共找到 {len(domains)} 个域名:\n")
        print(f"{'域名':<30} {'DomainId':<15} {'状态':<10}")
        print("-" * 55)
        for d in domains:
            name = d.get("Name", "")
            domain_id = d.get("DomainId", "")
            status = d.get("Status", "")
            print(f"{name:<30} {domain_id:<15} {status:<10}")
    else:
        print(f"\n请求失败:\n{json.dumps(result, indent=2, ensure_ascii=False)}")


if __name__ == "__main__":
    main()
